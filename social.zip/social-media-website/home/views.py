from django.http.response import JsonResponse
from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth import logout
from django.db.models import Q 

from home.extra.comment import comment_delete

from . feeds import feeds
from . models import *
MESSAGE_TAGS = {
    messages.ERROR: 'danger',
}
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
#from django.contrib.auth import authenticate, login
from django.contrib.auth import authenticate, login

from django.views.decorators.csrf import csrf_exempt

from .extra import comment
from datetime import datetime


# Create your views here.

@login_required(login_url='login')
def index(request):
    id=request.user.id
    #Topics
   
    if Following.objects.filter(Bywho=id).exists():
        myfeeds=feeds.feedalgo(id,0)
        suggest_feeds=feeds.suggestalgo(id,0)


        return render(request,'index.html',{'myfeed':myfeeds,'sf':suggest_feeds})
    else:
        suggest_feeds=feeds.suggestalgo(id,0)
        x=Account.objects.order_by('?')[:11]
        return render(request,'index.html',{'sf':suggest_feeds})



def Login(request):
    if request.method=='POST':
        username=request.POST.get("username")
        password=request.POST.get("password")

       
        #Check for User Credentials
        
        user = authenticate(request,username=username, password=password)
        if user is not None:
            print("Logging In")
            login(request,user)
            
        else:
            messages.warning(request,'Password or Username does not match!')
            return render(request,'login.html')
        
        return render(request,'index.html')

       
        
    return render(request,'login.html')

def Reset(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')
        if pass1 == pass2:
            u = User.objects.get(username=username)
            u.set_password(pass1)
            u.save()
        else:
            messages.warning(request,'Password or Username not matching!')
            return render(request,'reset.html')
        return render(request,'login.html')
    return render(request,'reset.html')


def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        username=request.POST.get('username')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')
        if pass1 == pass2:
            if User.objects.filter(username=username).exists():
                messages.warning(request,'User Exists!')
            else:
                user = User.objects.create_user(username=username, password=pass1)
                user.save()

                #Account Table
                x = Account(user=user,Email=username,Name=name)
                x.save()
                return render(request,'login.html')
        else:
            messages.warning(request,'Password not maching!')
            return render(request,'signup.html')
        
    return render(request,'signup.html')

    return render(request, 'signup.html')

@login_required(login_url='login')
def profile(request,id):
    prof=Account.objects.get(user=id)
    followers=Following.objects.filter(whom=id).count()
    followings=Following.objects.filter(Bywho=id).count()
    #Fetch the post
    post=Post.objects.filter(UID=id).order_by('-id')
    if Following.objects.filter(Bywho=request.user.id).filter(whom=id).exists():
        isFollow=True
    else:
        isFollow=False
    return render(request,'profile.html',{'p':prof,'i':isFollow,'folowr':followers,'folow':followings,'pst':post})

@login_required(login_url='login')
def follow(request,id):
#    print(id)
    if Following.objects.filter(Bywho=request.user.id).filter(whom=id).exists():
        x=Following.objects.filter(Bywho=request.user.id).filter(whom=id)
        x.delete()
    else:
        usr=User.objects.get(id=id)
        if usr != request.user:
            x=Following(Bywho=request.user,whom=usr)
            x.save()

       
    return redirect('/profile/'+str(id))


def upload(request):
    if request.method == 'POST':
        capt=request.POST.get('caption')
        content = request.POST.get('content')
        topic = request.POST.get('topic')
        img=request.FILES.get('image')
        style = request.POST.get('style')

        now = datetime.now()
        
    
        # dd/mm/YY H:M:S
        dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
        

        curent_ac=Account.objects.get(user=request.user)

        
        x=Post(UID=request.user,user=curent_ac,Caption=capt,post_topic=topic,posted_time=dt_string,style=style,post_content=content)
       
           
        x.save()


        return redirect('profile/'+str(request.user.id))
    return render(request,'upload.html')

@login_required(login_url='login')
def react(request):
    if request.method == 'POST':
        post_id=request.POST.get('pid')
    
        post=Post.objects.get(id=post_id)
        allLikes=post.Likes.all()
        # print(allLikes)
        if len(allLikes) == 0:
            post.Likes.add(request.user)
            c=post.Likes.count()
            post.Total_likes=c
            post.save()
            like=1
        else:
            for t in allLikes:
                # print(t)
                if t == request.user:
                    post.Likes.remove(request.user)
                    c=post.Likes.count()
                    post.Total_likes=c
                    post.save()
                    like=0
                    
                    break
                else:
                    post.Likes.add(request.user)
                    c=post.Likes.count()
                    post.Total_likes=c
                    post.save()
                    like=1
        return JsonResponse({'lk':like,'likecount':c})
    pass

def commentdelete(request):
    if request.method == 'POST':
        idstr = request.POST.get('pid')
        id = int(idstr.replace('z',''))
        # print(idstr)
        #Code for remove a comment
        comment_delete(id)
        return JsonResponse({'res':'ok'})


@login_required(login_url='login')
def comment(request,id):
    try:
        pst=Post.objects.get(id=id)
        cmts=Comment.objects.filter(PID=pst.id)
        return render(request,'comment.html',{'cmt':cmts,'post':pst})
    except:
        return render(request,'comment.html')

@login_required(login_url='login')
def commentreact(request):
    if request.method == 'POST':
        post_id=request.POST.get('pid')
    
        post=Comment.objects.get(id=post_id)  #post means comment
        allLikes=post.commentlike.all()
        #print(allLikes)
        if len(allLikes) == 0:
            post.commentlike.add(request.user)
            c=post.commentlike.count()
            post.Total_likes=c
            post.save()
            like=1
        else:
            for t in allLikes:
                # print(t)
                if t == request.user:
                    post.commentlike.remove(request.user)
                    c=post.commentlike.count()
                    post.Total_likes=c
                    post.save()
                    like=0
                    
                    break
                else:
                    post.commentlike.add(request.user)
                    c=post.commentlike.count()
                    post.Total_likes=c
                    post.save()
                    like=1
        return JsonResponse({'lk':like,'likecount':c})

def mycomment(request):
    if request.method == 'POST':
        cmt=request.POST.get('comment')
        pid=request.POST.get("myid")

        current_post=Post.objects.get(id=pid)
        ac=Account.objects.get(user=request.user)
        
        x=Comment(userid=request.user,PID=current_post,cmt=cmt,userac=ac)
        x.save()
        return comment(request,pid)
    return JsonResponse({'res':'ok'})


def deletepost(request,id):
    # if request.method == 'POST':
        usr=request.user
        pst=Post.objects.get(id=id)
        if usr == pst.UID:
            pst.delete()
        return redirect('/profile/'+str(request.user.id))
        

def search(request,term):
    if term != "" or term is not None:
        qs = Account.objects.all()
        
        for t in term.split():
            qs = qs.filter( Q(Name__icontains = t))
            # qry = qry.filter( Q(podcast_file__icontains = t))


          
        return render(request,'search.html',{'q':qs})
    else:
        return redirect('/')

def search1(request):
    return redirect('/')

def edit(request):
    if request.method == 'POST':
        name=request.POST.get('name')
        img=request.FILES.get('image')
        phone=request.POST.get('phone')
        bio=request.POST.get('bio')

        usr=User.objects.get(id=request.user.id)

        x=Account.objects.get(user=usr)

        if name != '':
            x.Name=name
        if img != None:
            x.profile_picture=img
        if phone != '':
            x.phone = phone
        if bio != '':
            x.Bio=bio
        x.save()
        return profile(request,request.user.id)
    
    x = Account.objects.get(user = request.user)
    return render(request,'edit.html',{"ac":x})

def lout(request):
    logout(request) 
    return index(request)

def share(request,id):
    x=Post.objects.get(id=id)
    return render(request,'post.html',{"i":x})


def followg(request,id):
    #People who follow by the user

    res_un = Following.objects.filter(Bywho = id)
    
    res = []

    for i in res_un:
        res.append(i.whom)

    usrs = Account.objects.filter(user__in = res)
    
    return render(request,'search.html',{'q':usrs})


def followers(request,id):
    #People who followed  the user

    res_un = Following.objects.filter(whom = id)
    
    res = []

    for i in res_un:
        res.append(i.Bywho)
    
    usrs = Account.objects.filter(user__in = res)

    return render(request,'search.html',{'q':usrs})



def sendMailNotification(request):
    #Get the UserId
    #Get list of users who follow Current user
    #Send maail function called inside a for loop
    userId = request.user
    
    #Fetch users who follow this user

    usrs = Following.objects.filter(whom=userId)
    for i in usrs:
        # send_mail(i.Bywho.)
        #Get the Email of user
        try:
            email = Account.objects.get(user=i.Bywho).Email
            # send_mail(email,"New post for you.")
        except:
            pass
    return JsonResponse({'hello':'ok'})

    
