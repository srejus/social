from django.contrib.auth.models import User
from django.db import models

from django.urls import reverse

from django.template.defaultfilters import slugify

# Create your models here.
class Account(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    Name=models.CharField(max_length=100,null=True,blank=True)
    Email=models.CharField(max_length=100,null=True,blank=True)
    phone=models.CharField(max_length=12,blank=True,null=True)
    profile_picture=models.ImageField(null=True,blank=True)
    Place=models.CharField(max_length=100,null=True,blank=True)
    Bio=models.TextField(null=True,blank=True)
    verified=models.BooleanField(default=False)
    def __str__(self): 
        try:
            rt=self.user.username+' ('+self.Name+')'
            return rt
        except:
            pass

class Post(models.Model):
    UID=models.ForeignKey(User,on_delete=models.CASCADE,related_name='uid')
    Time=models.DateTimeField(auto_now=True)
    posted_time = models.CharField(max_length=250,null=True,blank=True)
    user=models.ForeignKey(Account,on_delete=models.CASCADE,related_name='uid')
    Img=models.ImageField(upload_to="images",null=True,blank=True)
    Caption=models.TextField(null=True,blank=True)
    Likes=models.ManyToManyField(User,related_name='Post',null=True,blank=True)
    Total_likes=models.IntegerField(null=True,blank=True,default=0)
    post_topic = models.CharField(max_length=250,null=True,blank=True)
    post_content = models.TextField(default="",null=True,blank=True)
    total_views = models.IntegerField(default=0)
    slug = models.SlugField(null=True)
    style=models.CharField(max_length=20,default='stl-1')


    def get_absolute_url(self):
        kwargs = {
            'pk': self.id,
            'slug': self.slug
        }
        return reverse('post-pk-slug-title', kwargs=kwargs)

    def save(self, *args, **kwargs):
        if not self.id:
            self.slug = slugify(self.Caption)
        super(Post, self).save(*args, **kwargs)

    

    def isLiked(self,request):
        if Post.objects.filter(id=self.id).filter(Likes=request.user).exists():
            return 1
        else:
            return 0
    
    def get_absolute_url(self):
        return f'/reader/{self.id}/{self.slug}'
        # return reverse('home:reader',args=[self.id,])

class Comment(models.Model):
    userid=models.ForeignKey(User,on_delete=models.CASCADE,related_name='cmtuid')
    PID=models.ForeignKey(Post,on_delete=models.CASCADE,related_name='pid')
    Time=models.DateTimeField(auto_now=True)
    cmt=models.CharField(max_length=500,null=True,blank=True)
    userac=models.ForeignKey(Account,on_delete=models.CASCADE,related_name='userac')
    commentlike=models.ManyToManyField(User,related_name='cmtlike',null=True,blank=True)
    Total_likes=models.IntegerField(null=True,blank=True,default=0)




class Following(models.Model):
    Bywho=models.ForeignKey(User,on_delete=models.CASCADE,null=True,related_name='follower')#aru follow cheyunnu
    whom=models.ForeignKey(User,on_delete=models.CASCADE,null=True,related_name='following')#are follow cheyunnu


class Blog(models.Model):
    title = models.CharField(max_length=250)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    content = models.TextField(null=True,blank=True)
    Time=models.DateTimeField(auto_now=True)
    posted_time = models.CharField(max_length=250,null=True,blank=True)

    def __str__(self):
        return self.title

